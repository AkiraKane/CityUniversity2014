# -*- coding: utf-8 -*-
"""
Created on Fri Mar 27 20:56:21 2015

@author: dan
"""

import os

working_directory = os.getcwd()

print working_directory + '/Python'