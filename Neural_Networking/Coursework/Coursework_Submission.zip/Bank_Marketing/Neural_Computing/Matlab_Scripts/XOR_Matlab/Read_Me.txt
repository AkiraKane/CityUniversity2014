Daniel Dixey

% Date:     19/2/2015
% Title:    Feed Forward One Layer Neural Network
% Author:   Daniel Dixey

% Main Function: 
% 	feed_forward_neural_net.m

% Application:
% 	Matlab

% Developed: 
%   From reading the literature

% Purpose: 
%   Use previous matlab experiance
%   Understand the mechanics of the neural network mathematically

% Description:
%   Attempting to build a feed forward - Successful
%   A one layer Neural Network where nInput = nOutputs
