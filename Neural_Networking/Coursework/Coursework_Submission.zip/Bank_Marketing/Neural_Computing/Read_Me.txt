Information:
    All CSV files have been generated as a result of running the 'Neural_Computing_Coursework.py' Python script.
