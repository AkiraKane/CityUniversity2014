Coursework Algorithm:
    Neural_Computing_Courswork.py
    
Developer:
    Daniel Dixey
    James Muller
    
Implementation:
    3 Neural Networks
        1   -   Multi-Layer Perceptron with stochasic online learning
        2   -   Multi-Layer Perceptron with stochasic online learning used in conjection with a SMOTE algorithm to boost the minority class
        3   -   Multi-Layer Perceptron with stochasic online learning used in conjuction with a Restricted Bolztmann Machine to boost the minority class

Date Completed:
    25/3/2015
    
Contents of Folder:
    Confusion_Matrix_Plots - contains Confusion matrix plots of the top 15 Neural Network models
    Development - developmental scripts used for building the Python script
    Others - other plots
    ROC_Plots - contains ROC plots of the top 15 Neural Network models
    Neural_Computing_Coursework.py - the main python script for the Coursework
    Results_Python_Script.xlsx - a combination of the results in one excel file
