Author: 
	Daniel Dixey

Date Completed:
	6/3/2015

Main Function:
	Collect_Results.m

Application:
	Matlab

Description/Purpose:
	Implement a Multilayer Neural Network
	Develop a script from scratch
	Complete the coursework

Other Information:
	- The code used was implemented Batch processing, using the whole dataset for each epoch.
	- The result of this was an incredibly slow converging Neural Network
	- The decision was to migrate over to Python for faster processing, easier to integrate with ML 		   algorithms within the Scikit Learn module.
	- The allcomb function has been used, the license for that function is contain within this   folder. This would have been used for Grid Search.
	
