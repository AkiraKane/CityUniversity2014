Original Data: 
    bank-additional.zip

Download Date: 
    26/2/2015

Information:
    Data has not been modified, only extracted from the bank-additional.zip file.
