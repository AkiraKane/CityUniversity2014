function y = activation(x)
    % Return the Sigmoid Fuction
    y = 1 / (1 + exp(-x));    
    
    % TO DO STRING TO FUNCTION AS SHOWN IN ARTURs SCRIPT